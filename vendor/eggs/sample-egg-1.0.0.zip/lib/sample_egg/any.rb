# coding: utf-8
module SampleEgg::Any
  # any codes
end
