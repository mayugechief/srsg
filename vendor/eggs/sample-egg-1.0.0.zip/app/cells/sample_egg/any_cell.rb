# coding: utf-8
class SampleEgg::AnyCell < Cell::Rails
  # any codes
end
