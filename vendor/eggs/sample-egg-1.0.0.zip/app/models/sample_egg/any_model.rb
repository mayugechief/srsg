# coding: utf-8
class SampleEgg::AnyModel
  # any codes
end
