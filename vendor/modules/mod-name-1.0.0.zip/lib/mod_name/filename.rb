# coding: utf-8
module ModName::Filename
  # any actions
end
