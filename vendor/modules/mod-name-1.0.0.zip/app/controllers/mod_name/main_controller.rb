# coding: utf-8
class ModName::MainController < ApplicationController
  # any actions
end
