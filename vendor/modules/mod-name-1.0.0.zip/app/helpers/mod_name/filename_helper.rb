# coding: utf-8
module ModName::FilenameHelper
  # any methods
end
