# coding: utf-8
class ModName::Filename
  # any methods
end
