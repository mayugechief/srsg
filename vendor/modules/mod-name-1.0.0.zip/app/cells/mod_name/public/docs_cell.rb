# coding: utf-8
class ModName::Public::DocsCell < Cell::Rails
  # any actions
end
